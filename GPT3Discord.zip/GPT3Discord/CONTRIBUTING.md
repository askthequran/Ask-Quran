Please contribute on your own branch and make a pull request for review. There are not many other guidelines to follow, I'd love to see all of your good ideas. 
